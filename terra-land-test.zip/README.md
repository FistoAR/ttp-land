# TTP Land — Plot Management System
## Backend Setup Guide

---

## Project Structure

```
project/
├── server.js              ← Express entry point
├── db.js                  ← MySQL connection pool
├── schema.sql             ← Run once to create database & tables
├── package.json
├── .env                   ← Your local config (never commit this)
├── middleware/
│   └── auth.js            ← Session auth guard
├── routes/
│   ├── auth.js            ← POST /api/auth/login, /logout, GET /me
│   ├── plots.js           ← GET/PUT /api/plots, PATCH /api/plots/:key/status
│   ├── customers.js       ← GET/POST/DELETE /api/customers
│   └── mediators.js       ← GET/POST/DELETE /api/mediators
└── public/                ← ⬅ Put your frontend files here
    ├── index.html
    ├── script.js          ← Updated API-integrated version
    ├── style.css
    ├── plot_final_1.svg
    └── logo-terra.png
```

---

## Step 1 — MySQL Setup

Make sure MySQL is installed and running, then:

```bash
mysql -u root -p < schema.sql
```

This creates the `ttp_land` database with all tables and seeds:
- Default admin user (`admin` / `admin123`)
- 7 mediators
- 6 plots

---

## Step 2 — Configure Environment

Edit `.env`:

```env
PORT=3000
DB_HOST=localhost
DB_PORT=3306
DB_USER=root
DB_PASSWORD=your_actual_mysql_password
DB_NAME=ttp_land
SESSION_SECRET=change_this_to_a_long_random_string
```

---

## Step 3 — Install Dependencies

```bash
npm install
```

---

## Step 4 — Place Frontend Files

Copy your frontend files into the `public/` folder:
```
public/index.html       ← your HTML (unchanged)
public/script.js        ← USE THE NEW script.js from this package
public/style.css        ← your CSS (unchanged)
public/plot_final_1.svg ← your SVG file
public/logo-terra.png
public/favicon.png
```

---

## Step 5 — Start the Server

```bash
# Production
npm start

# Development (auto-restart on changes)
npm run dev
```

Open: **http://localhost:3000**

---

## API Endpoints

| Method | Endpoint                    | Auth | Description                          |
|--------|-----------------------------|------|--------------------------------------|
| GET    | `/api/auth/me`              | No   | Check current session                |
| POST   | `/api/auth/login`           | No   | Login with username + password       |
| POST   | `/api/auth/logout`          | No   | Destroy session                      |
| GET    | `/api/plots`                | No   | Get all plots (as plotDB object)     |
| PUT    | `/api/plots/:key`           | Yes  | Update plot price/dims/facing        |
| PATCH  | `/api/plots/:key/status`    | Yes  | Update plot status only              |
| GET    | `/api/customers`            | Yes  | Get all customers + installments     |
| POST   | `/api/customers`            | Yes  | Save new customer + update plot      |
| DELETE | `/api/customers/:id`        | Yes  | Delete a customer                    |
| GET    | `/api/mediators`            | No   | Get all mediators                    |
| POST   | `/api/mediators`            | Yes  | Add/update a mediator                |
| DELETE | `/api/mediators/:id`        | Yes  | Delete a mediator                    |

---

## Key Change: SVG Color Updates Only After Successful Save

In the old version, plot colors changed as soon as the user clicked a radio button.
Now, **the SVG color and stamp are only applied after the API call succeeds**:

```
User selects status radio → preview in popup only (no SVG change)
User clicks Save          → POST /api/customers
API success              → THEN applyPlotStatusOnSVG() runs
API failure              → Toast error, SVG unchanged
```

---

## Changing the Admin Password

Generate a new bcrypt hash:
```bash
node -e "const b=require('bcryptjs'); b.hash('newpassword', 10).then(h => console.log(h));"
```

Then update the database:
```sql
UPDATE users SET password = '<hash>' WHERE username = 'admin';
```

---

## Adding More Users

```sql
INSERT INTO users (username, password, display_name, role)
VALUES ('staff1', '<bcrypt_hash>', 'Staff User', 'staff');
```
#   T T P _ L A N D  
 